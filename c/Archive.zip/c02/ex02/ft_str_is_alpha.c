/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: youngwch <youngwch@student.42seoul.>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/05 20:37:53 by youngwch          #+#    #+#             */
/*   Updated: 2022/10/05 20:46:55 by youngwch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	is_non_alpha(char ch)
{
	if (ch < 'A' || ch > 'z' || (ch < 'a' && ch > 'Z'))
	{
		return (1);
	}
	else
		return (0);
}

int	ft_str_is_alpha(char *str)
{
	int	i;

	i = 0;
	while (*(str + i))
	{
		if (is_non_alpha(*(str + i)))
			return (0);
		else
			i ++;
	}
	return (1);
}
