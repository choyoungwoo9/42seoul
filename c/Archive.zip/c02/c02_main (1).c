/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: seok <seok@student.42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/29 17:35:07 by seok              #+#    #+#             */
/*   Updated: 2022/10/20 16:51:50 by youngwch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ex00/ft_strcpy.c"
#include "ex01/ft_strncpy.c"
#include "ex02/ft_str_is_alpha.c"
#include "ex03/ft_str_is_numeric.c"
#include "ex04/ft_str_is_lowercase.c"
#include "ex05/ft_str_is_uppercase.c"
#include "ex06/ft_str_is_printable.c"
#include "ex07/ft_strupcase.c"
#include "ex08/ft_strlowcase.c"
#include "ex09/ft_strcapitalize.c"
#include "ex10/ft_strlcpy.c"
#include "ex11/ft_putstr_non_printable.c"
#include "ex12/ft_print_memory.c"

#include <stdio.h>
#include <string.h>

int	main()
{
	printf("==========c02============\n");
	
	printf("------ex00-------\n");
	char	dest[10];
	char	src1[6] = "hello";
	char	src2[9] = "happyday";
	printf("정답\t\t제출\n");
	printf("%s\t\t%s\n", strcpy(dest, src1), ft_strcpy(dest, src1));
	printf("%s\t%s\n", strcpy(dest, src2), ft_strcpy(dest, src2));
	printf("------ex01-------\n");
	char	dest1[10];
	char	dest6[10];
	char	src11[6] = "hello";
	char	src22[9] = "happyday";
	printf("정답\t\t제출\n");
	printf("%s\t\t%s\n", strncpy(dest1, src11, 4), ft_strncpy(dest6, src11, 4));
	printf("%s\t\t%s\n", strncpy(dest1, src22, 5), ft_strncpy(dest6, src22, 5));
	printf("------ex02-------\n");
	char	str[10] = "01234";
	char	str1[10] = "01abc";
	char	str2[10] = "";
	char	str3[10] = "abcd";
	char	str4[10] = "ASP";
	printf("0이면 정답 : %d\n", ft_str_is_alpha(str));
	printf("1이면 정답 : %d\n", ft_str_is_alpha(str4));
	printf("1이면 정답 : %d\n", ft_str_is_alpha(str2));
	printf("------ex03-------\n");
	printf("1이면 정답 : %d\n", ft_str_is_numeric(str));
	printf("0이면 정답 : %d\n", ft_str_is_numeric(str1));
	printf("1이면 정답 : %d\n", ft_str_is_numeric(str2));
	printf("------ex04-------\n");
	printf("1이면 정답 : %d\n", ft_str_is_lowercase(str3));
	printf("0이면 정답 : %d\n", ft_str_is_lowercase(str4));
	printf("1이면 정답 : %d\n", ft_str_is_lowercase(str2));
	printf("------ex05-------\n");
	printf("1이면 정답 : %d\n", ft_str_is_uppercase(str4));
	printf("0이면 정답 : %d\n", ft_str_is_uppercase(str3));
	printf("1이면 정답 : %d\n", ft_str_is_uppercase(str2));
	printf("------ex06-------\n");
	printf("1이면 정답 : %d\n", ft_str_is_printable(str3));
	printf("0이면 정답 : %d\n", ft_str_is_printable("\n\t"));
	printf("1이면 정답 : %d\n", ft_str_is_printable(str2));
	printf("------ex07-------\n");
	char	arr[100] = "hello!";
	ft_strupcase(arr);
	printf("HELLO!이면 정답 : %s\n", arr);
	printf("------ex08-------\n");
	ft_strlowcase(arr);
	printf("hello!이면 정답 : %s\n", arr);
	printf("------ex09-------\n");
	char	test[100] = "sAlut, comment tu vas ? 42mots quarante-deux; cinquante+et+un";
	ft_strcapitalize(test);
	printf("똑같으면 정답\nSalut, Comment Tu Vas ? 42mots Quarante-Deux; Cinquante+Et+Un\n");
	printf("%s\n", test);
	printf("------ex10-------\n");
	char	destt[10];
	char	strr[10] = "hello";
	char	strr1[10] = "to";
	printf("정답\t출력\n");
	printf("%lu\t%u\n", strlcpy(destt, strr, 4), ft_strlcpy(destt, strr, 4));
	printf("%lu\t%u\n", strlcpy(destt, strr1, 2), ft_strlcpy(destt, strr1, 2));
	printf("------ex11-------\n");
	char	string[100] = "Coucou\ntu vas bien ?";
	printf("똑같으면 정답\nCoucou\\0atu vas bien ?\n");
	ft_putstr_non_printable(string);
	printf("\n\n\n------ex12-------\n");
	printf("**test1**\n");
	char str12[] = "Bonjour les aminches\t\n\tc  est fou\ttout\tce qu on peut faire avec\t\n\tprint_memory\n\n\n\tlol.lol. \n";
	char	blank[] = "";
	//blank[] = "";
	ft_print_memory((void *)str12, sizeof(str12));
	printf("\nmain_ex12.c파일로 컴파일 후 './a.out | cat -e'로 실행하여 마지막 행의 문자열 출력 부분에 ..lol.lol. .$이라고 정확하게 나오는지 꼭 확인 후 push 하세요!\n\n**test2**\n");
	printf("\t\tblank_address : %p\n\n\nblank가 존재하긴합니다. 하지만\n", blank);
	ft_print_memory(blank, 0);
	printf("위 문자와 현재 문자 사이에 아무것도 출력되지 않으면  size가 0일때를 의미합니다.\n\n");
	printf("**test3**\n");
	char	no[] = "aaaaaaaaaaaaaaaabbbbbbbbbbbbbbbb";
	ft_print_memory((void *)no, 16);

	printf("\n\n**test4(42testcase)**\n");
char	test4[] = "\n\\,\nl\n\n)\n\n\n\n\n\n\n\n\n-_\n\n\n\n\n>\n\n\n\n\no\n\n\n\n\n\n\n\n\n\nT\nr=a\nU\n\nA\n_\n\nZx\n\n\n\n~\n\n\n\nI\n\n\n]l\n\n\n\n\n\n\n\n\n\n]\n\n\n\n\na\n\n\n\n\n]\n\n\n\n\n\na\n\n\n\n2\n\n\n}\nM\n\n;\n\n\n;\ne\n\n\nj\n\nM\n\n\n\n\n\n\n\n\n\np\n\n\n\n\n\n";
	ft_print_memory((void *)test4, sizeof(test4));
	printf("\n\n");
	ft_print_memory((void *)test4, 1);
	ft_print_memory((void *)test4, 2);
	ft_print_memory((void *)test4, 3);
	ft_print_memory((void *)test4, 4);
	ft_print_memory((void *)test4, 5);
	ft_print_memory((void *)test4, 6);
	
	return (0);
}
