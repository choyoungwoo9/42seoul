/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: youngwch <youngwch@student.42seoul.>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/07 10:21:24 by youngwch          #+#    #+#             */
/*   Updated: 2022/10/07 20:17:26 by youngwch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int	i;
	int				gap;

	i = 0;
	while (*(s1 + i) || *(s2 + i))
	{
		if(i >= n)
			return 0;
		gap = *(s1 + i) - *(s2 + i);
		if (gap != 0)
			return (gap);
		i ++;
	}
	return (*(s1 + i) - *(s2 + i));
}
