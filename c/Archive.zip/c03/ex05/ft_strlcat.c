/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: youngwch <youngwch@student.42seoul.>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/07 07:53:21 by youngwch          #+#    #+#             */
/*   Updated: 2022/10/07 10:43:06 by youngwch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	find_array_length(char *ar)
{
	int	i;

	i = 0;
	while (*(ar + i))
	{
		i ++;
	}
	return (i);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	dest_length;
	unsigned int	src_length;
	int				k;

	dest_length = find_array_length(dest);
	src_length = find_array_length(src);
	k = 0;
	if (size > dest_length)
	{
		while (*(src + k))
		{
			if (size > k + dest_length + 1)
				*(dest + dest_length + k) = *(src + k);
			else
			{
				*(dest + dest_length + k) = '\0';
				return (dest_length + src_length);
			}
			k ++;
		}
		*(dest + dest_length + k) = '\0';
		return (dest_length + src_length);
	}
	return (size + src_length);
}
