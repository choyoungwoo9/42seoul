/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: youngwch <youngwch@student.42seoul.>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/07 07:50:40 by youngwch          #+#    #+#             */
/*   Updated: 2022/10/07 10:23:56 by youngwch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strstr(char *str, char *to_find)
{
	int	i;
	int	j;

	i = 0;
	if (!*to_find)
		return (str);
	while (*(str + i))
	{
		if (*(str + i) == *(to_find))
		{
			j = 0;
			while (*(to_find + j))
			{
				if (*(str + i + j) == *(to_find + j))
					j ++;
				else
					break ;
			}
			if (!*(to_find + j))
				return (str + i);
		}
		i ++;
	}
	return (0);
}
