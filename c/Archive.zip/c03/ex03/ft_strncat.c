/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: youngwch <youngwch@student.42seoul.>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/07 07:48:27 by youngwch          #+#    #+#             */
/*   Updated: 2022/10/07 07:50:30 by youngwch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	unsigned int	i;
	unsigned int	j;

	i = 0;
	j = 0;
	while (*(dest + i))
	{
		i ++;
	}
	while (*(src + j) && j < nb)
	{
		*(dest + i + j) = *(src + j);
		j ++;
	}
	*(dest + i + j) = '\0';
	return (dest);
}
