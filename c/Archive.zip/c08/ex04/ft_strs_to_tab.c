/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strs_to_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: youngwch <youngwch@student.42seoul.>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/16 17:18:30 by youngwch          #+#    #+#             */
/*   Updated: 2022/10/16 22:20:26 by youngwch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<stdlib.h>
#include"ft_stock_str.h"

int	assign_alloc_ptr(int i, char **av, t_stock_str *ptr)
{
	int	length;

	length = 0;
	while (*(*(av + i) + length))
		length ++;
	(*(ptr + i)).size = length;
	(*(ptr + i)).str = *(av + i);
	(*(ptr + i)).copy = (char *)malloc(sizeof(char) * (length + 1));
	if ((*(ptr + i)).copy == NULL)
		return (-1);
	length = 0;
	while (*(*(av + i) + length))
	{
		*((*(ptr + i)).copy + length) = *(*(av + i) + length);
		length ++;
	}
	*((*(ptr + i)).copy + length) = '\0';
	return (0);
}

struct	s_stock_str	*ft_strs_to_tab(int ac, char **av)
{
	t_stock_str	*ptr;
	int			i;
	int			length;

	i = 0;
	length = 0;
	ptr = (t_stock_str *)malloc(sizeof(t_stock_str) * (ac + 1));
	if (ptr == NULL)
		return (NULL);
	while (i < ac)
	{
		if (assign_alloc_ptr(i, av, ptr) == -1)
			return (NULL);
		i ++;
	}
	(*(ptr + i)).str = NULL;
	return (ptr);
}
