/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_show_tab.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: youngwch <youngwch@student.42seoul.>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/16 17:06:53 by youngwch          #+#    #+#             */
/*   Updated: 2022/10/16 17:18:07 by youngwch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<unistd.h>
#include"ft_stock_str.h"

void	size_write(int nb)
{
	char	ch;

	if (nb > 0)
	{
		size_write(nb / 10);
		ch = '0' + nb % 10;
		write(1, &ch, 1);
	}
}

void	ft_show_tab(struct s_stock_str *par)
{
	int	i;

	i = 0;
	while ((*(par + i)).str)
	{
		write(1, (*(par + i)).str, (*(par + i)).size);
		write(1, "\n", 1);
		if ((*(par + i)).size == 0)
			write(1, "0", 1);
		else
			size_write((*(par + i)).size);
		write(1, "\n", 1);
		write(1, (*(par + i)).copy, (*(par + i)).size);
		write(1, "\n", 1);
		i ++;
	}
}
