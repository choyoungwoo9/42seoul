/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_map.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: youngwch <youngwch@student.42seoul.>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/18 22:11:26 by youngwch          #+#    #+#             */
/*   Updated: 2022/10/18 22:32:09 by youngwch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<stdlib.h>

int	*ft_map(int *tab, int length, int (*f)(int))
{
	int	i;
	int	*return_ar;

	return_ar = (int *)malloc(sizeof(int) * length);
	i = 0;
	while (i < length)
	{
		*(return_ar + i) = f(*(tab + i));
		i ++;
	}
	return (return_ar);
}
