/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: youngwch <youngwch@student.42seoul.>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/19 15:33:06 by youngwch          #+#    #+#             */
/*   Updated: 2022/10/19 15:56:15 by youngwch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<unistd.h>

int	ft_putnbr(int nb);

void	op_add(int a, int b)
{
	ft_putnbr(a + b);
	write(1, "\n", 1);
}

void	op_sub(int a, int b)
{
	ft_putnbr(a - b);
	write(1, "\n", 1);
}

void	op_mul(int a, int b)
{
	ft_putnbr(a * b);
	write(1, "\n", 1);
}

void	op_div(int a, int b)
{
	if (b == 0)
	{
		write(1, "Stop : division by zero\n", 24);
		return ;
	}
	ft_putnbr(a / b);
	write(1, "\n", 1);
}

void	op_mod(int a, int b)
{
	if (b == 0)
	{
		write(1, "Stop : modulo by zero\n", 22);
		return ;
	}
	ft_putnbr(a % b);
	write(1, "\n", 1);
}
