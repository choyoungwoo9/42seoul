/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_sort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: youngwch <youngwch@student.42seoul.>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/19 08:17:35 by youngwch          #+#    #+#             */
/*   Updated: 2022/10/19 09:37:20 by youngwch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_is_sort(int *tab, int length, int (*f)(int, int))
{
	int	i;
	int	sign;
	int	tem;

	i = 0;
	sign = 0;
	while (i < length - 1)
	{
		tem = f(*(tab + i), *(tab + i + 1));
		if (tem < 0)
		{
			if (sign > 0)
				return (0);
			sign = tem;
		}
		else if (tem > 0)
		{
			if (sign < 0)
				return (0);
			sign = tem;
		}
		i ++;
	}
	return (1);
}
