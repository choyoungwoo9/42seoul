/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_string_tab.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: youngwch <youngwch@student.42seoul.>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/10/19 09:48:04 by youngwch          #+#    #+#             */
/*   Updated: 2022/10/20 06:49:18 by youngwch         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ascii_comp(char *str1, char *str2)
{
	int	i;

	i = 0;
	while (*(str1 + i) || *(str2 + i))
	{
		if (*(str1 + i) != *(str2 + i))
			return (*(str1 + i) - *(str2 + i));
		i ++;
	}
	return (0);
}

void	ft_sort_string_tab(char **tab)
{
	int		i;
	int		j;
	char	*tmp;
	int		length;

	length = 0;
	while (*(tab + length))
		length ++;
	i = 0;
	while (i < length - 1)
	{
		j = 0;
		while (j < length - i - 1)
		{
			if (ascii_comp(*(tab + j), *(tab + j + 1)) > 0)
			{
				tmp = *(tab + j);
				*(tab + j) = *(tab + j + 1);
				*(tab + j + 1) = tmp;
			}
			j ++;
		}
		i ++;
	}
}
